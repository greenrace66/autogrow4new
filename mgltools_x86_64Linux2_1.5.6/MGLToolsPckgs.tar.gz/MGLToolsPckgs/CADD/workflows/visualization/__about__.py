
about =         "The Visualization workflows verison 0.1 provide tools\n"
about = about + "for visualization of the simulation results. Available tools:\n"
about = about + "  - VSResults - visualization of virtual screening results\n"
