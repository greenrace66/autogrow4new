
about = "The Docking workflows verison 0.1 provide tools to run separate steps "
about = about + "of virtual scrreening. Available tools:\n"
about = about + " - PrepareReceptor  - create PDBQT file \n"
about = about + " - Autogrid  - generate all the grid map files for use with AutoDock \n"
about = about + " - AutodockSL - run docking for a single ligand \n"
