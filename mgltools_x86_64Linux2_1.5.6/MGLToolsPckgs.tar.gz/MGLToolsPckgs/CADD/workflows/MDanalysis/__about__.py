
about = "The MD Analysis workflows provide Molecular dynamics tools:\n"
about = about + "   GROMOS - trajectory clustering using GROMOS\n"
about = about + "   TrajQR - trajectory clustering using TrajQR\n"
about = about + "   NAMD_TG - NAMD-based calculation using TeraGRid resources\n"
about = about + "   NAMD_NBCR - NAMD-based calculation using NBCR resources\n"
