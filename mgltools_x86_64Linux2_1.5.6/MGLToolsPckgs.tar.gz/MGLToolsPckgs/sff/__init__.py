#
# copyright_notice
#

__MGLTOOLSVersion__ = '1-4alpha3'
CRITICAL_DEPENDENCIES = ['Numeric', 'mglutil']
NONCRITICAL_DEPENDENCIES = ['MolKit']

