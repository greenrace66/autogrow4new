CRITICAL_DEPENDENCIES = ['mglutil', 'numpy']
NONCRITICAL_DEPENDENCIES = ['NetworkEditor', 'MolKit', 'DejaVu', 'Vision']


