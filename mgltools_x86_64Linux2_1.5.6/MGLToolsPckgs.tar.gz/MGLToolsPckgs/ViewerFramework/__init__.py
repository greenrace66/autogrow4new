#
# $Header: /opt/cvs/python/packages/share1.5/ViewerFramework/__init__.py,v 1.20 2010/07/07 23:52:30 annao Exp $
#
# $Id: __init__.py,v 1.20 2010/07/07 23:52:30 annao Exp $
#


packageContainsVFCommands = 1
CRITICAL_DEPENDENCIES = ['DejaVu', 'mglutil','Pmw', 'numpy', 'opengltk', 'Support']
NONCRITICAL_DEPENDENCIES = ['Vision','PIL', 'Pmv', 'Volume', 'UTpackages', 'MolKit', 'TkinterDnD2']
